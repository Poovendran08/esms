<?php include('../functions.php');
    
    if (!isLoggedIn()) {
	$_SESSION['msg'] = "You must log in first";
	header('location: login.php');
}
?>
<!-- php code by Povendran -->

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="32x32" href="static/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="static/favicons/favicon-16x16.png">
    <title>E-Staff Movement System</title>
    <link rel="stylesheet" href="static/css/custom-font.css">
    <link rel="stylesheet" href="static/css/fontawesome.min.css">
    <link rel="stylesheet" href="static/css/solid.min.css">
    <link rel="stylesheet" href="static/css/esms.min.css">
  </head>

  <body>
    <?php include 'navigation.php'; ?>
    <div class="container-fluid pb-1">
      <h1 class="h3 mb-4 font-weight-light">Leave</h1>

      <div class="card mb-5 shadow">
        <div class="card-header">
          <h2 class="h6 mb-0 font-weight-bold">Leave details</h2>
        </div>

        <div class="card-body pt-3">
          <div class="row">
            <div class="col-xl col-lg col-md col-sm"></div>
            <div class="col-xl-3 col-lg-4 col-md-5 col-sm-6">
              <form action="#" method="post">
                <div class="form-group">
                  <label for="typeOfLeave">Type of leave</label>
                  <select id="typeOfLeave" class="form-control" name="typeOfLeave" required>
                    <option value="">Select type of leave</option>
                    <option value="Annual leave">Annual leave</option>
                    <option value="Compassionate leave">Compassionate leave</option>
                    <option value="Emergency leave">Emergency leave</option>
                    <option value="Examination leave">Examination leave</option>
                    <option value="Hospitalization leave">Hospitalization leave</option>
                    <option value="Maternity leave">Maternity leave</option>
                    <option value="Medical leave">Medical leave</option>
                    <option value="Paternity leave">Paternity leave</option>
                    <option value="Replacement leave">Replacement leave</option>
                    <option value="Study leave">Study leave</option>
                    <option value="Unpaid leave">Unpaid leave</option>
                    <option value="Others">Others</option>
                  </select>
                </div>

                <div class="form-group">
                  <label for="durationOfLeave">Duration of leave</label>
                  <select id="durationOfLeave" class="form-control" name="durationOfLeave" required>
                    <option value="">Select duration of leave</option>
                    <option value="0.5">Half day</option>
                    <option value="1">1 day</option>
                    <option value="2">2 days</option>
                    <option value="3">3 days</option>
                    <option value="4">4 days</option>
                    <option value="5">5 days</option>
                    <option value="6">6 days</option>
                    <option value="7">7 days</option>
                    <option value="8">8 days</option>
                    <option value="9">9 days</option>
                    <option value="10">10 days</option>
                    <option value="11">11 days</option>
                    <option value="12">12 days</option>
                    <option value="13">13 days</option>
                    <option value="14">14 days</option>
                    <option value="15">15 days</option>
                    <option value="16">16 days</option>
                    <option value="17">17 days</option>
                    <option value="18">18 days</option>
                    <option value="19">19 days</option>
                    <option value="20">20 days</option>
                    <option value="21">21 days</option>
                    <option value="22">22 days</option>
                    <option value="23">23 days</option>
                    <option value="24">24 days</option>
                    <option value="25">25 days</option>
                    <option value="26">26 days</option>
                    <option value="27">27 days</option>
                    <option value="28">28 days</option>
                    <option value="29">29 days</option>
                    <option value="30">30 days</option>
                  </select>
                </div>

                <div class="form-group">
                  <label for="dateOfLeave">Date of leave</label>
                  <input type="date" id="dateOfLeave" onfocus="this.showPicker()" class="form-control" pattern="^(0[1-9]|[12][0-9]|3[01])[/](0[1-9]|1[012])[/](19|20)\d\d$" title="dd/mm/yyyy" name="dateOfLeave" date-format="dd/mm/yyyy" required>
                </div>

                <div class="form-group">
                  <label for="purposeOfLeave">Purpose of leave</label>
                  <input type="text" id="purposeOfLeave" class="form-control" placeholder="Enter purpose of leave" name="purposeOfLeave">
                </div>

                <button type="submit" class="btn btn-primary mt-2">Submit</button>
              </form>
            </div>
            <div class="col-xl col-lg col-md col-sm"></div>
          </div>
        </div>
      </div>
    </div>
    <?php include 'footer.php'; ?>

    <script src="static/js/jquery.min.js"></script>
    <script src="static/js/popper.min.js"></script>
    <script src="static/js/bootstrap.min.js"></script>
    <script src="static/js/solid.min.js"></script>
    <script src="static/js/configurable-date-input-polyfill.dist.js"></script>
  </body>
</html>
<!-- User interface design by Thu Wen Bin -->
