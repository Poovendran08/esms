<?php 
include('../functions.php');

if (!isAdmin()) {
	$_SESSION['msg'] = "You must log in first";
	header('location: ../login.php');
}

if (isset($_GET['logout'])) {
	session_destroy();
	unset($_SESSION['user']);
	header("location: ../login.php");
}
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="32x32" href="static/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="static/favicons/favicon-16x16.png">
    <title>Home | E-Staff Movement System</title>
    <link href="static/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="static/css/all.min.css" rel="stylesheet">
    <link href="static/css/nunito.css" rel="stylesheet">
    <link href="static/css/custom-styles.css" rel="stylesheet">
  </head>

  <body id="page-top">
    <div id="wrapper">
      <div id="content-wrapper">
        <?php include 'navigation-menu.php'; ?>
        <div class="container-fluid pb-1">
          <p class="h3 mb-4 font-weight-light">Ler Lum Advisory Services Sdn&nbsp;Bhd</p>
          <div class="card mb-5 shadow">
            <div class="card-header py-2">
              <p class="mb-0 font-weight-bold">Home</p>
            </div>

            <div class="card-body pt-3 pb-0">
              <p>To notify your departure, please <a href="departure-form.php">click here</a>.</p>
              <p>To apply for leave, please <a href="leave-form.php">click here</a>.</p>
              <p>To view your departure history, please <a href="departure-records.php">click here</a>.</p>
              <p>To view your applied leaves, please <a href="leave-records.php">click here</a>.</p>
              <p>To change your password, please <a href="requestReset.php">click here</a>.</p>
              <p>To add or remove users, please <a href="user-account.php">click here</a>.</p>
                
                
            </div>
          </div>
        </div>
        <?php include 'sticky-footer.php'; ?>
      </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <script src="static/js/jquery.min.js"></script>
    <script src="static/js/bootstrap.bundle.min.js"></script>
    <script src="static/js/sb-admin-2.min.js"></script>
    <script src="static/js/jquery.easing.min.js"></script>
  </body>
</html>