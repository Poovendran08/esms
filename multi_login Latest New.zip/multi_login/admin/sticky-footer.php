<?php

echo '
        <footer class="sticky-footer pb-3 shadow">
          <p class="copyright text-center">Version 2023.06</p>
        </footer>
';
