<?php 
    include('functions.php');
    
    if (!isLoggedIn()) {
	$_SESSION['msg'] = "You must log in first";
	header('location: login.php');
}
?>
<!-- php code by Povendran -->

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="32x32" href="static/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="static/favicons/favicon-16x16.png">
    <title>E-Staff Movement System</title>
    <link rel="stylesheet" href="static/css/custom-font.css">
    <link rel="stylesheet" href="static/css/fontawesome.min.css">
    <link rel="stylesheet" href="static/css/solid.min.css">
    <link rel="stylesheet" href="static/css/esms.min.css">
  </head>

  <body>
    <?php include 'navigation.php'; ?>
    <div class="container-fluid pb-1">
      <h1 class="h3 mb-4 font-weight-light">Departure</h1>

      <div class="card mb-5 shadow">
        <div class="card-header">
          <h2 class="h6 mb-0 font-weight-bold">Departure details</h2>
        </div>

        <div class="card-body pt-3">
          <div class="row">
            <div class="col-xl col-lg col-md col-sm"></div>
            <div class="col-xl col-lg-5 col-md-7 col-sm-9">
              <form action="#" method="post">
                <div class="form-row">
                  <div class="col-sm form-group">
                    <label for="departureDate">Departure date</label>
                    <input type="date" id="departureDate" onfocus="this.showPicker()" class="form-control" pattern="^(0[1-9]|[12][0-9]|3[01])[/](0[1-9]|1[012])[/](19|20)\d\d$" title="dd/mm/yyyy" name="departureDate" date-format="dd/mm/yyyy" required>
                  </div>

                  <div class="col-sm form-group">
                    <label for="departureTime">Departure time</label>
                    <input type="time" id="departureTime" onfocus="this.showPicker()" class="form-control" name="departureTime" required>
                  </div>
                </div>

                <div class="form-group">
                  <label for="location">Location</label>
                  <input type="text" id="location" class="form-control" placeholder="Enter location" name="location" required>
                </div>

                <div class="form-row">
                  <div class="col-sm form-group">
                    <label for="returnDate">Return date</label>
                    <input type="date" id="returnDate" onfocus="this.showPicker()" class="form-control" pattern="^(0[1-9]|[12][0-9]|3[01])[/](0[1-9]|1[012])[/](19|20)\d\d$" title="dd/mm/yyyy" name="returnDate" date-format="dd/mm/yyyy" required>
                  </div>

                  <div class="col-sm form-group">
                    <label for="returnTime">Return time</label>
                    <input type="time" id="returnTime" onfocus="this.showPicker()" class="form-control" name="returnTime" required>
                  </div>
                </div>

                <div class="form-group">
                  <label for="purpose">Purpose</label>
                  <input type="text" id="purpose" class="form-control" placeholder="Enter purpose" name="purpose" required>
                </div>

                <button type="submit" class="btn btn-primary mt-2">Submit</button>
              </form>
            </div>
            <div class="col-xl col-lg col-md col-sm"></div>
          </div>
        </div>
      </div>
    </div>
    <?php include 'footer.php'; ?>

    <script src="static/js/jquery.min.js"></script>
    <script src="static/js/popper.min.js"></script>
    <script src="static/js/bootstrap.min.js"></script>
    <script src="static/js/solid.min.js"></script>
    <script src="static/js/configurable-date-input-polyfill.dist.js"></script>
    <script src="static/js/time-input-polyfill.auto.min.js"></script>
  </body>
</html>
<!-- User interface design by Thu Wen Bin -->
