-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2023 at 01:56 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esms`
--

-- --------------------------------------------------------

--
-- Table structure for table `departure_form`
--

CREATE TABLE `departure_form` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `departureDate` date NOT NULL,
  `departureTime` time NOT NULL,
  `location` varchar(100) NOT NULL,
  `purpose` varchar(1000) NOT NULL,
  `returnDate` date NOT NULL,
  `returnTime` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `departure_form`
--

INSERT INTO `departure_form` (`id`, `user_id`, `departureDate`, `departureTime`, `location`, `purpose`, `returnDate`, `returnTime`) VALUES
(6, NULL, '2023-04-07', '20:18:00', 'subang jaya', 'training', '2023-04-07', '21:18:00'),
(14, NULL, '2023-04-08', '18:00:00', 'usertest1', 'usertest1', '2023-04-10', '18:00:00'),
(15, NULL, '2023-04-08', '18:07:00', 'admintest1', 'admintest1', '2023-04-11', '06:07:00'),
(16, NULL, '2023-04-08', '19:47:00', 'poovendrantest', 'poovendrantest', '2023-04-08', '07:48:00');

-- --------------------------------------------------------

--
-- Table structure for table `leave_form`
--

CREATE TABLE `leave_form` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `typeOfLeave` varchar(100) NOT NULL,
  `dateOfLeave` date NOT NULL,
  `leaveDuration` int(100) NOT NULL,
  `remark` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `leave_form`
--

INSERT INTO `leave_form` (`id`, `user_id`, `typeOfLeave`, `dateOfLeave`, `leaveDuration`, `remark`) VALUES
(10, NULL, 'Emergency leave', '2023-04-07', 1, 'will be back tmr'),
(17, NULL, 'Annual leave', '2023-04-08', 5, 'usertest1'),
(18, NULL, 'Annual leave', '2023-04-10', 2, 'admintest1');

-- --------------------------------------------------------

--
-- Table structure for table `resetpasswords`
--

CREATE TABLE `resetpasswords` (
  `id` int(11) NOT NULL,
  `code` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(12) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `user_type` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `employee_id`, `username`, `email`, `user_type`, `password`) VALUES
(2, 'J18028252', 'Poovendrangaming', 'poovendrangaming@gmail.com', 'admin', '827ccb0eea8a706c4c34a16891f84e7b'),
(14, 'J18028251', 'Poovendran', 'poovendran306@gmail.com', 'user', '202cb962ac59075b964b07152d234b70'),
(16, 'J18028253', 'usertest1', 'poovendran3061@gmail.com', 'user', '202cb962ac59075b964b07152d234b70'),
(17, 'J18028254', 'user2', 'poovendran3062@gmail.com', 'user', '202cb962ac59075b964b07152d234b70');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `departure_form`
--
ALTER TABLE `departure_form`
  ADD PRIMARY KEY (`id`),
  ADD KEY `departure_user_id` (`user_id`);

--
-- Indexes for table `leave_form`
--
ALTER TABLE `leave_form`
  ADD PRIMARY KEY (`id`),
  ADD KEY `leave_user_id` (`user_id`);

--
-- Indexes for table `resetpasswords`
--
ALTER TABLE `resetpasswords`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `departure_form`
--
ALTER TABLE `departure_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `leave_form`
--
ALTER TABLE `leave_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `resetpasswords`
--
ALTER TABLE `resetpasswords`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `departure_form`
--
ALTER TABLE `departure_form`
  ADD CONSTRAINT `departure_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `leave_form`
--
ALTER TABLE `leave_form`
  ADD CONSTRAINT `leave_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
