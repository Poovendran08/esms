<?php
session_start();
$conn = mysqli_connect("localhost","root","","esms");

if(isset($_POST['update_stud_data']))
{
    $username = $_POST['username'];

    
    $name = $_POST['name'];
    $email = $_POST['email'];
    $user_type = $_POST['user_type'];

    $query = "UPDATE users SET name='$name', email='$email', user_type='$user_type' WHERE username='$username' ";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Data Updated Successfully";
        header("Location: user-account.php");
    }
    else
    {
        $_SESSION['status'] = "Not Updated";
        header("Location: user-account.php");
    }
}

?>