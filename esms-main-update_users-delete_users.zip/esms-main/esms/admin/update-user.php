<?php
include("database.php");
include('../functions.php');

$sql = "UPDATE users set name='" . $_POST['name'] . "', username='" . $_POST['username'] . "' , email='" . $_POST['email'] . "' , user_type='" . $_POST['user_type'] . "' WHERE username='" . $_POST['username'] . "'";
if (mysqli_query($conn, $sql)) {
    //echo "Record updated successfully";
    header('location:user-account.php');
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
mysqli_close($conn);
?>

<!-- php code by Povendran -->

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="32x32" href="static/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="static/favicons/favicon-16x16.png">
    <title>E-Staff Movement System</title>
    <link rel="stylesheet" href="static/css/custom-font.css">
    <link rel="stylesheet" href="static/css/fontawesome.min.css">
    <link rel="stylesheet" href="static/css/solid.min.css">
    <link rel="stylesheet" href="static/css/esms.min.css">
  </head>

  <body>
    <?php include 'navigation.php'; ?>
    <div class="container-fluid pb-1">
      <h1 class="h3 mb-4 font-weight-light">Users > All users > Update</h1>

      <div class="card mb-5 shadow">
        <div class="card-header">
          <h2 class="h6 mb-0 font-weight-bold">User details</h2>
        </div>

        <div class="card-body pt-3">
          <div class="d-flex justify-content-center">
            
                
                
           
                
                
               <div class="form-group">
                <label for="name">Employee name</label>
                <input type="text" id="name" class="form-control" value="<?php echo $row['name']; ?>" placeholder="Enter employee name" name="name" required>
              </div>
                
              <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" class="form-control" value="<?php echo $row['username']; ?>" placeholder="Enter username" name="username" required>
              </div>

              <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" class="form-control" value="<?php echo $row['email']; ?>" placeholder="Enter email" name="email" required>
              </div>

              <div class="form-group">
			<label>User type</label>  
        <select name="user_type" class="form-control" id="user_type" >
				<option value="">Select user type</option>
				<option value="admin">Admin</option>
				<option value="user">User</option>
			</select>
		</div>

              <button type="submit" name="submit" value="Submit" class="btn btn-primary mt-2">Save</button>
            </form>
          </div>
        </div>
      </div>
    </div>
    <?php include 'footer.php'; ?>

    <script src="static/js/jquery.min.js"></script>
    <script src="static/js/popper.min.js"></script>
    <script src="static/js/bootstrap.min.js"></script>
    <script src="static/js/solid.min.js"></script>
  </body>
</html>
<!-- User interface design and php code by Poovendran -->
