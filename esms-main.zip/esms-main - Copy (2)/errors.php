<?php  if (count($errors) > 0) : ?>
  <div class="error" style="background: #F2DEDE;
   color: #A94442;
   padding: 5px;
   font-size: 18px;
   width: 100%;
   border-radius: 5px;
   margin: 1px auto;" >
  	<?php foreach ($errors as $error) : ?>
  	  <p><?php echo $error ?></p>
  	<?php endforeach ?>
  </div>
<?php  endif ?>