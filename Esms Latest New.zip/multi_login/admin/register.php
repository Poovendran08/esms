<?php include('../functions.php') ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="32x32" href="static/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="static/favicons/favicon-16x16.png">
    <title>Account | E-Staff Movement System</title>
    <link href="static/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="static/css/all.min.css" rel="stylesheet">
    <link href="static/css/nunito.css" rel="stylesheet">
    <link href="static/css/custom-styles.css" rel="stylesheet">
  </head>
    
<body id="page-top">
    <div id="wrapper">
      <div id="content-wrapper">
        <?php include 'navigation-menu.php'; ?>
        <div class="container-fluid pb-1">
          <p class="h2 mb-4 font-weight-light">Ler Lum Advisory Services Sdn&nbsp;Bhd</p>
          <div class="card mb-5 shadow">
            <div class="card-header pt-3 pb-0">
              <p class="font-weight-bold">Add User</p>
            </div>
              
            <div class="card-body pb-4">
              <div class="d-flex justify-content-center">
    
    
<form method="post" action="register.php">
	<?php echo display_error(); ?>
    
    <div class="form-group">
		<label>Employee ID</label>
		<input type="text" name="employee_id" value="<?php echo $employee_id; ?>" required>
	</div>
	<div class="form-group">
		<label>Username</label>
		<input type="text" name="username" value="<?php echo $username; ?>" required>
	</div>
	<div class="form-group">
		<label>Email</label>
		<input type="email" name="email" value="<?php echo $email; ?>" required>
	</div>
    
    <div class="form-group">
			<label>User type</label>
			<select name="user_type" id="user_type" >
				<option value=""></option>
				<option value="admin">Admin</option>
				<option value="user">User</option>
			</select>
		</div>
    
	<div class="form-group">
		<label>Password</label>
		<input type="password" name="password_1" required>
	</div>
	<div class="form-group">
		<label>Confirm password</label>
		<input type="password" name="password_2" required>
	</div>
	<div class="form-group">
		<button class="btn btn-primary" type="submit" class="btn" name="register_btn">Add</button>
	</div>
</form>
                  
              </div>
            </div>
          </div>
        </div>
        <?php include 'sticky-footer.php'; ?>
      </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <script src="static/js/jquery.min.js"></script>
    <script src="static/js/bootstrap.bundle.min.js"></script>
    <script src="static/js/sb-admin-2.min.js"></script>
    <script src="static/js/jquery.easing.min.js"></script>
  </body>
</html>