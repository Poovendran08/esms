<?php
include("user-account-dev.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="32x32" href="static/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="static/favicons/favicon-16x16.png">
    <title>Departures | E-Staff Movement System</title>
    <link href="static/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="static/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link href="static/css/all.min.css" rel="stylesheet">
    <link href="static/css/nunito.css" rel="stylesheet">
    <link href="static/css/custom-styles.css" rel="stylesheet">
  </head>

  <body id="page-top">
    <div id="wrapper">
      <div id="content-wrapper">
        <?php include 'navigation-menu.php';?>       
        <div class="container-fluid pb-1">
          <p class="h2 mb-4 font-weight-light">Ler Lum Advisory Services Sdn&nbsp;Bhd</p>
          <div class="card mb-5 shadow">
            <div class="card-header pt-3 pb-0">
              <p class="font-weight-bold">All user account <a class="text-decoration-none ml-3" href="user-account.php">
            <i class="fas fa-redo fa-sm fa-fw"></i>
            <span>Refresh</span>
          </a></p>  
            </div>

            <div class="card-body pb-4">
              <div class="table-responsive">
                <table class="table table-bordered nowrap" id="dataTable">
                  <thead>
                    <tr>
                      <th>Employee ID</th>
                      <th>Employee Name</th>
                      <th>Employee Email</th>
                      <th>Employee Rank</th>
                    </tr>
                  </thead>

                  <tbody>
    <?php
      if(is_array($fetchData)){      
      $sn=1;
      foreach($fetchData as $data){
    ?>
      <tr>
      <td><?php echo $data['employee_id']??''; ?></td>
      <td><?php echo $data['username']??''; ?></td>
      <td><?php echo $data['email']??''; ?></td>
      <td><?php echo $data['user_type']??''; ?></td>
     </tr>
     <?php
      $sn++;}}else{ ?>
      <tr>
        <td colspan="8">
    <?php echo $fetchData; ?>
  </td>
    <tr>
    <?php
    }?>     
                  </tbody>
                </table>
     
                 <input style="float: left;
	background: #007BFF;
	padding: 10px 15px;
	color: #fff;
	border-radius: 5px;
	margin-left: 10px;
	border: none;"type="button" name="submit" value="Add" onclick="location='register.php'" /> 
                  
                  <input style="float: left;
	background: #007BFF;
	padding: 10px 15px;
	color: #fff;
	border-radius: 5px;
	margin-left: 10px;
	border: none;"type="button" name="submit" value="Delete" onclick="location='delete.php'" /> 
                             
              </div>
            </div>
          </div>
        </div>
        <?php include 'sticky-footer.php'; ?>
      </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <script src="static/js/jquery.min.js"></script>
    <script src="static/js/bootstrap.bundle.min.js"></script>
    <script src="static/js/jquery.dataTables.min.js"></script>
    <script src="static/js/datatables-initialization.js"></script>
    <script src="static/js/dataTables.bootstrap4.min.js"></script>
    <script src="static/js/sb-admin-2.min.js"></script>
    <script src="static/js/jquery.easing.min.js"></script>
  </body>
</html>
