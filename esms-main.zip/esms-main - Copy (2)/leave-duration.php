<?php

for ($i = 2; $i <= 98; $i++) {
    echo '<option value="' . $i . '">' . $i . ' days' . '</option>' . "\n";

    if ($i !== 98) {
        echo '                      ';
    }
}
