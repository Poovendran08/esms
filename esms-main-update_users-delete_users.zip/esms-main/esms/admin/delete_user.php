<?php
include("database.php");
include('../functions.php');

$sql = "DELETE FROM users WHERE username='" . $_GET["username"] . "'";
if (mysqli_query($conn, $sql)) {
    //echo "Record deleted successfully";
    header('location:user-account.php');
} else {
    echo "Error deleting record: " . mysqli_error($conn);
}
mysqli_close($conn);
?>
