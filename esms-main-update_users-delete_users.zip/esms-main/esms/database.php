<?php
$hostName = "localhost";
$userName = "root";
$password = "";
$databaseName = "esms";
 $conn = new mysqli($hostName, $userName, $password, $databaseName);
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
?>

<!-- full file done by Poovendran -->