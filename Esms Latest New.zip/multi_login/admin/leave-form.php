<?php
include("leave-form-dev.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="32x32" href="static/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="static/favicons/favicon-16x16.png">
    <title>Leave form | E-Staff Movement System</title>
    <link href="static/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="static/css/all.min.css" rel="stylesheet">
    <link href="static/css/nunito.css" rel="stylesheet">
    <link href="static/css/custom-styles.css" rel="stylesheet">
  </head>

  <body id="page-top">
    <div id="wrapper">
      <div id="content-wrapper">
        <?php include 'navigation-menu.php'; ?>
        <div class="container-fluid pb-1">
          <p class="h3 mb-4 font-weight-light">Ler Lum Advisory Services Sdn&nbsp;Bhd</p>
          <div class="card mb-5 shadow">
            <div class="card-header py-2">
              <p class="mb-0 font-weight-bold">Leave form</p>
            </div>

            <div class="card-body pt-3">
              <div class="d-flex justify-content-center">
                
                
              <p><?php echo !empty($result)? $result:''; ?></p> 
                
              <form method="post" >
                  
                <div class="form-group">
                  <label for="typeOfLeave">Type of leave</label>
                  <select class="form-control" id="typeOfLeave" name="typeOfLeave" required>
                    <option value="">Select type of leave</option>
                    <option value="Annual leave">Annual leave</option>
                    <option value="Compassionate leave">Compassionate leave</option>
                    <option value="Emergency leave">Emergency leave</option>
                    <option value="Hospitalization leave">Hospitalization leave</option>
                    <option value="Maternity leave">Maternity leave</option>
                    <option value="Paternity leave">Paternity leave</option>
                    <option value="Replacement leave">Replacement leave</option>
                    <option value="Sick leave">Sick leave</option>
                    <option value="Unpaid leave">Unpaid leave</option>
                    <option value="Volunteer leave">Volunteer leave</option>
                  </select>
                </div>

                <div class="form-group">
                    <label for="dateOfLeave">Date of leave</label>
                    <input class="form-control" type="date" id="dateOfLeave" name="dateOfLeave" onfocus="this.showPicker()" required>
                  </div>

                  <div class="form-group">
                    <label for="leaveDuration">Leave duration</label>
                    <select class="form-control" id="leaveDuration" name="leaveDuration" required>
                      <option value="">Select leave duration</option>
                      <option value="0.5">Half day</option>
                      <option value="1">1 day</option>
                      <?php include 'leave-duration.php'; ?>
                    </select>
                  </div>
            

                <div class="form-group">
                  <label for="remark">Remark</label>
                  <input class="form-control" type="text" id="remark" name="remark" placeholder="Enter remark">
                </div>

                <div class="mb-4"></div>
                <button type="submit"  name="save" class="btn btn-primary">Submit</button>
              </form>
            </div>
          </div>
        </div>
        </div>
       <?php include 'sticky-footer.php'; ?>
      </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <script src="static/js/jquery.min.js"></script>
    <script src="static/js/bootstrap.bundle.min.js"></script>
    <script src="static/js/sb-admin-2.min.js"></script>
    <script src="static/js/jquery.easing.min.js"></script>
  </body>
</html>
