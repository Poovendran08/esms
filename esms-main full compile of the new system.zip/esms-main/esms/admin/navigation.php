<?php

echo '<nav class="navbar navbar-expand-md mb-5 bg-white navbar-light shadow">
      <a href="home.php">
        <img src="static/images/logo-50x60.png" class="ml-2" width="50" height="60" alt="Logo of LLAS">
      </a>

      <button type="button" class="navbar-toggler mr-2" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div id="navbarNav" class="navbar-collapse collapse ml-2">
        <ul class="navbar-nav">
          <li>
            <a href="home.php" class="nav-link">Dashboard</a>
          </li>

          <li>
            <a href="records.php" class="nav-link">Records</a>
          </li>

          <li>
            <a href="departure.php" class="nav-link">Departure</a>
          </li>

          <li>
            <a href="leave.php" class="nav-link">Leave</a>
          </li>

          <li>
            <a href="user-account.php" class="nav-link">Users</a>
          </li>
        </ul>

        <ul class="navbar-nav ml-auto">
          <li class="dropdown">
            <a href="#" id="displayNameDropdown" class="dropdown-toggle nav-link" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Dr Amy Lim Swee Geok</a>

            <div class="dropdown-menu dropdown-menu-right mr-2 shadow" aria-labelledby="displayNameDropdown">
               <a class="dropdown-item" href="home.php?logout=1">
                <i class="fa-solid fa-arrow-right-from-bracket mr-1 fa-fw" aria-hidden="true"></i>
                Log out
              </a>

              <div class="dropdown-divider"></div>

              <a href="request.php" class="dropdown-item">
                <i class="fa-solid fa-comment mr-1 fa-fw" aria-hidden="true"></i>
                Request
              </a>

              <div class="dropdown-divider"></div>

              <a href="history.php" class="dropdown-item">
                <i class="fa-solid fa-clock-rotate-left mr-1 fa-fw" aria-hidden="true"></i>
                History
              </a>

              <div class="dropdown-divider"></div>

              <a href="my_account.php" class="dropdown-item">
                <i class="fa-solid fa-circle-user mr-1 fa-fw" aria-hidden="true"></i>
                Account
              </a>
            </div>
          </li>
        </ul>
      </div>
    </nav>

';

//code edited by Poovendran
