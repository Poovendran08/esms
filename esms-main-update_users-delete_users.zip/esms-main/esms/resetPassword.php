<?php include("functions.php"); 

if(!isset($_GET["code"])){
    exit("Can't find the page");
}

$code = $_GET["code"];

$getEmailQuery = mysqli_query($conn, "SELECT email FROM resetPasswords WHERE code='$code'");
if(mysqli_num_rows($getEmailQuery) ==0){
    exit("Can't find the page");
}

if(isset($_POST["password"])){
    $pw = $_POST["password"];
    $pw = md5($pw); //encryption
    
    $row = mysqli_fetch_array($getEmailQuery);
    $email = $row["email"];
    
    $query = mysqli_query($conn, "UPDATE users SET password='$pw' WHERE email='$email'");
    
    if($query){
        $query = mysqli_query($conn, "DELETE FROM resetPasswords WHERE code='$code'");
        
        echo "<script type='text/javascript'>alert('Password updated');</script>";
        exit("");
    }
    else{
        exit("Something went wrong");
    }
}
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="32x32" href="static/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="static/favicons/favicon-16x16.png">
    <title>E-Staff Movement System</title>
    <link rel="stylesheet" href="static/css/custom-font.css">
    <link rel="stylesheet" href="static/css/fontawesome.min.css">
    <link rel="stylesheet" href="static/css/solid.min.css">
    <link rel="stylesheet" href="static/css/esms.min.css">
  </head>

  <body class="vh-100 d-flex align-items-center">
    <div class="container">
      <div class="row justify-content-center">
        <div class="card shadow-lg border-0">
          <div class="card-body p-0">
            <div class="d-flex justify-content-center">
              <div class="px-4 pt-4 pb-3">
                <div class="text-center">
                  <img src="static/images/logo-50x60.png" class="mb-2" width="50" height="60" alt="Logo of LLAS">
                  <h1 class="h4 mb-4">E-Staff Movement System</h1>
                </div>

                <form method="post">
                    
                 <div class="form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa-solid fa-key fa-fw" aria-hidden="true"></i>
                        </div>
                      </div>
                      <input type="text" class="form-control" placeholder="New password" name="password" required>
                    </div>
                  </div>

                  <button type="submit" class="btn btn-primary btn-user btn-block" name="submit">Update Password</button>
                </form>
                <br>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script src="static/js/solid.min.js"></script>
  </body>
</html>

<!-- full file done by Poovendran -->


    