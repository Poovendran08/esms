<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

require 'functions.php';



if(isset($_POST["email"])){
    
    $emailTo = $_POST["email"];
    
    $code = uniqid(true);
    $query = mysqli_query($conn, "INSERT INTO resetPasswords(code, email) VALUES('$code', '$emailTo')");
    if(!$query){
        exit("Reset Password Error");
    }
    
    
    //Create an instance; passing `true` enables exceptions
    $mail = new PHPMailer(true);
    try {
        //Server settings
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'poovendran306@gmail.com';                     //SMTP username
        $mail->Password   = 'cbtdnmivvjjsozjk';                               //SMTP password
        $mail->SMTPSecure = 'tls';                              //Enable implicit TLS encryption
        $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

        //Recipients
        $mail->setFrom('poovendran306@gmail.com', 'ESMS'); //set email for phpMailer
        $mail->addAddress($emailTo);     //Add a recipient
        $mail->addReplyTo('no-reply@gmail.com', 'No reply');

        //Content
        $url = "http://" . $_SERVER["HTTP_HOST"] . dirname($_SERVER["PHP_SELF"]) . "/resetPassword.php?code=$code";
        
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'Reset Password Code';
        $mail->Body    = "<h1> you requested password reset </h1>
                         Click <a href='$url'>this link</a> to do so";

        $mail->send();
        
echo '<script type ="text/JavaScript">';  
echo 'alert("Reset Password Link Has Been Send To Your Email")';  
echo '</script>'; 
        
        
        echo '<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="32x32" href="static/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="static/favicons/favicon-16x16.png">
    <title>E-Staff Movement System</title>
    <link rel="stylesheet" href="static/css/custom-font.css">
    <link rel="stylesheet" href="static/css/fontawesome.min.css">
    <link rel="stylesheet" href="static/css/solid.min.css">
    <link rel="stylesheet" href="static/css/esms.min.css">
  </head>

  <body class="vh-100 d-flex align-items-center">
    <div class="container">
      <div class="row justify-content-center">
        <div class="card shadow-lg border-0">
          <div class="card-body p-0">
            <div class="d-flex justify-content-center">
              <div class="px-4 pt-4 pb-3">
  
                <div class="text-center">
                  <img src="static/images/logo-50x60.png" class="mb-2" width="50" height="60" alt="Logo of LLAS">
                  <h1 class="h4 mb-4">E-Staff Movement System</h1>
                </div>

                <form method="post" action="login.php">
                    
                    <?php echo display_error(); ?>
                    
                  <div class="form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa-solid fa-user fa-fw" aria-hidden="true"></i>
                        </div>
                      </div>
                      <input type="text" class="form-control" placeholder="Username" name="username" required>
                    </div>
                  </div>

                  <div class="form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa-solid fa-key fa-fw" aria-hidden="true"></i>
                        </div>
                      </div>
                      <input type="password" class="form-control" placeholder="Password" name="password" required>
                    </div>
                  </div>

                  <button type="submit" class="btn btn-primary btn-user btn-block" name="login_btn">Log in</button>
                </form>
                <br>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script src="static/js/solid.min.js"></script>
  </body>
</html>';
        
        
         
        
    } catch (Exception $e) {
        echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
    }
    exit();
}
?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="32x32" href="static/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="static/favicons/favicon-16x16.png">
    <title>E-Staff Movement System</title>
    <link rel="stylesheet" href="static/css/custom-font.css">
    <link rel="stylesheet" href="static/css/fontawesome.min.css">
    <link rel="stylesheet" href="static/css/solid.min.css">
    <link rel="stylesheet" href="static/css/esms.min.css">
  </head>

  <body class="vh-100 d-flex align-items-center">
    <div class="container">
      <div class="row justify-content-center">
        <div class="card shadow-lg border-0">
          <div class="card-body p-0">
            <div class="d-flex justify-content-center">
              <div class="px-4 pt-4 pb-3">
                <div class="text-center">
                  <img src="static/images/logo-50x60.png" class="mb-2" width="50" height="60" alt="Logo of LLAS">
                  <h1 class="h4 mb-4">E-Staff Movement System</h1>
                </div>

                <form method="post" >
                    
                  <div class="form-group">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <div class="input-group-text">
                          <i class="fa-solid fa-user fa-fw" aria-hidden="true"></i>
                        </div>
                      </div>
                      <input type="text" class="form-control" placeholder="Email" name="email" required>
                    </div>
                  </div>

                  <button type="submit" class="btn btn-primary btn-user btn-block" name="submit">Reset Password</button>
                </form>
                <br>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <script src="static/js/solid.min.js"></script>
  </body>
</html>

<!-- full file done by Poovendran -->










