$(document).ready(function () {
  $('.dataTables').DataTable();
});
