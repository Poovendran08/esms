<?php
include("departure-form-dev.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="32x32" href="static/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="static/favicons/favicon-16x16.png">
    <title>Departure form | E-Staff Movement System</title>
    <link href="static/css/sb-admin-2.min.css" rel="stylesheet">
    <link href="static/css/all.min.css" rel="stylesheet">
    <link href="static/css/nunito.css" rel="stylesheet">
    <link href="static/css/custom-styles.css" rel="stylesheet">
  </head>

  <body id="page-top">
    <div id="wrapper">
      <div id="content-wrapper">
        <?php include 'navigation-menu.php'; ?>
        <div class="container-fluid pb-1">
          <p class="h3 mb-4 font-weight-light">Ler Lum Advisory Services Sdn&nbsp;Bhd</p>
          <div class="card mb-5 shadow">
            <div class="card-header py-2">
              <p class="mb-0 font-weight-bold">Departure form</p>
            </div>

            <div class="card-body pt-3">
              <div class="d-flex justify-content-center">
                
                
               <p><?php echo !empty($result)? $result:''; ?></p> 
                
              <form method="post" >
                  
                <div class="form-row">
                    <div class="col-lg-6 form-group">
                      <label for="departureDate">Departure date</label>
                      <input class="form-control" type="date" id="departureDate" name="departureDate" onfocus="this.showPicker()" required>
                    </div>

                    <div class="col-lg-6 form-group">
                      <label for="departureTime">Departure time</label>
                      <input class="form-control" type="time" id="departureTime" name="departureTime" onfocus="this.showPicker()" required>
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="location">Location</label>
                    <input class="form-control" type="text" id="location" name="location" placeholder="Enter location" required>
                  </div>

                  <div class="form-row">
                    <div class="col-lg-6 form-group">
                      <label for="returnDate">Return date</label>
                      <input class="form-control" type="date" id="returnDate" name="returnDate" onfocus="this.showPicker()" required>
                    </div>

                    <div class="col-lg-6 form-group">
                      <label for="returnTime">Return time</label>
                      <input class="form-control" type="time" id="returnTime" name="returnTime" onfocus="this.showPicker()" required>
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="purpose">Purpose</label>
                    <input class="form-control" type="text" id="purpose" name="purpose" placeholder="Enter purpose" required>
                  </div>

                  <div class="mb-4"></div>
                  <button type="submit"  name="save" class="btn btn-primary">Submit</button>
                </form>
              </div>
            </div>
          </div>
        </div>
        <?php include 'sticky-footer.php'; ?>
      </div>
    </div>

    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <script src="static/js/jquery.min.js"></script>
    <script src="static/js/bootstrap.bundle.min.js"></script>
    <script src="static/js/sb-admin-2.min.js"></script>
    <script src="static/js/jquery.easing.min.js"></script>
  </body>
</html>
