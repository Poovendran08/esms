<?php include('server.php') ?>

<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="header">
  	<h2>Login</h2>
  </div>
	 
  <form method="post" action="index.php">
      
      <img src="lerlum.jpg" width="430">
      
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  		<label>Email Address</label>
  		<input type="text" name="email" autocomplete="off">
  	</div>
  	<div class="input-group">
  		<label>Password</label>
  		<input type="password" name="password" autocomplete="off">
  	</div>
  	<div class="input-group">
        
  		<br><a href="requestReset.php">Forgot Password</p><br>
  	</div>
      <button type="submit" class="btn" name="login_user">Login</button>
  </form>
</body>
</html>