<?php
include("database.php");

extract($_POST);
if(isset($save)){

$inputData = [
    //'id' => validate($id) ?? "", //havent fix
'departureDate' => validate($departureDate) ?? "",
'departureTime'   => validate($departureTime) ?? "",
'location'    => validate($location) ?? "",
'purpose'   => validate($purpose) ?? "",
'returnDate'  => validate($returnDate) ?? "",
'returnTime'     => validate($returnTime) ?? ""
];

$tableName= "departure_form";
$db = $conn;
$result= insert_data($db, $tableName, $inputData);

}

function insert_data($db, $tableName, $inputData){

 $data = implode(" ",$inputData);
if(empty($db)){
 $msg= "Database connection error";
}elseif(empty($tableName)){
  $msg= "Table Name is empty";
}elseif(trim( $data ) == ""){
  $msg= "Empty Data not allowed to insert";
}else{

    $query  = "INSERT INTO ".$tableName." (";
    $query .= implode(",", array_keys($inputData)) . ') VALUES (';
    $query .= "'" . implode("','", array_values($inputData)) . "')";
    $execute= $db->query($query);
   if($execute=== false){
  $msg= "fail to get data";
 }
}
 

}

function validate($value) {
  $value = trim($value);
  $value = stripslashes($value);
  $value = htmlspecialchars($value);
  return $value;
}

?>