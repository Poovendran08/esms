-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 07, 2023 at 01:32 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `esms`
--

-- --------------------------------------------------------

--
-- Table structure for table `departure_form`
--

CREATE TABLE `departure_form` (
  `id` int(11) NOT NULL,
  `user_id` int(100) DEFAULT NULL,
  `departureDate` date NOT NULL,
  `departureTime` time NOT NULL,
  `location` varchar(100) NOT NULL,
  `purpose` varchar(1000) NOT NULL,
  `returnDate` date NOT NULL,
  `returnTime` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `departure_form`
--

INSERT INTO `departure_form` (`id`, `user_id`, `departureDate`, `departureTime`, `location`, `purpose`, `returnDate`, `returnTime`) VALUES
(3, NULL, '2023-04-08', '16:09:00', 'subang jaya', 'training', '2023-04-10', '16:10:00'),
(4, NULL, '2023-04-14', '18:14:00', 'jb', 'not feeling well', '2023-04-21', '18:16:00'),
(5, NULL, '2023-04-12', '18:43:00', 'subang jaya selangor', 'poo', '2023-04-28', '18:47:00');

-- --------------------------------------------------------

--
-- Table structure for table `leave_form`
--

CREATE TABLE `leave_form` (
  `id` int(11) NOT NULL,
  `user_id` int(100) DEFAULT NULL,
  `typeOfLeave` varchar(100) NOT NULL,
  `dateOfLeave` date NOT NULL,
  `leaveDuration` int(100) NOT NULL,
  `remark` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `leave_form`
--

INSERT INTO `leave_form` (`id`, `user_id`, `typeOfLeave`, `dateOfLeave`, `leaveDuration`, `remark`) VALUES
(9, NULL, 'Annual leave', '2023-04-08', 2, 'will be back soon');

-- --------------------------------------------------------

--
-- Table structure for table `resetpasswords`
--

CREATE TABLE `resetpasswords` (
  `id` int(11) NOT NULL,
  `code` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(12) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `employee_id`, `username`, `email`, `password`) VALUES
(3, 'J18028251', 'Poovendran', 'poovendran306@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b'),
(5, 'J18028252', 'Poovendrangaming', 'poovendrangaming@gmail.com', '827ccb0eea8a706c4c34a16891f84e7b');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `departure_form`
--
ALTER TABLE `departure_form`
  ADD PRIMARY KEY (`id`),
  ADD KEY `departure_user_id` (`user_id`);

--
-- Indexes for table `leave_form`
--
ALTER TABLE `leave_form`
  ADD PRIMARY KEY (`id`),
  ADD KEY `leave_user_id` (`user_id`);

--
-- Indexes for table `resetpasswords`
--
ALTER TABLE `resetpasswords`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `departure_form`
--
ALTER TABLE `departure_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `leave_form`
--
ALTER TABLE `leave_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `resetpasswords`
--
ALTER TABLE `resetpasswords`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `departure_form`
--
ALTER TABLE `departure_form`
  ADD CONSTRAINT `departure_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `leave_form`
--
ALTER TABLE `leave_form`
  ADD CONSTRAINT `leave_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
