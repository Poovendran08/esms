<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

require 'functions.php';



if(isset($_POST["email"])){
    
    $emailTo = $_POST["email"];
    
    $code = uniqid(true);
    $query = mysqli_query($conn, "INSERT INTO resetPasswords(code, email) VALUES('$code', '$emailTo')");
    if(!$query){
        exit("Reset Password Error");
    }
    
    
    //Create an instance; passing `true` enables exceptions
    $mail = new PHPMailer(true);
    try {
        //Server settings
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
        $mail->Username   = 'poovendran306@gmail.com';                     //SMTP username
        $mail->Password   = 'cbtdnmivvjjsozjk';                               //SMTP password
        $mail->SMTPSecure = 'tls';                              //Enable implicit TLS encryption
        $mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

        //Recipients
        $mail->setFrom('poovendran306@gmail.com', 'ESMS'); //set email for phpMailer
        $mail->addAddress($emailTo);     //Add a recipient
        $mail->addReplyTo('no-reply@gmail.com', 'No reply');

        //Content
        $url = "http://" . $_SERVER["HTTP_HOST"] . dirname($_SERVER["PHP_SELF"]) . "/resetPassword.php?code=$code";
        
        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = 'Reset Password Code';
        $mail->Body    = "<h1> you requested password reset </h1>
                         Click <a href='$url'>this link</a> to do so";

        $mail->send();
        echo 'Reset Password Link Has Been Send To Your Email';
        
       
        echo "<br>";
        echo "<br>";
        
        
        echo '<form method="POST" action="login.php"><input style="float: left;
	background: #007BFF;
	padding: 10px 15px;
	color: #fff;
	border-radius: 5px;
	margin-left: 10px;
	border: none;" type="submit" name="submit" value="Back To Login Page"></form>';
        
        
         
        
    } catch (Exception $e) {
        echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
    }
    exit();
}
?>



<!DOCTYPE html>
<html>
<head>
	
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
     <form method="post">
         
     <img src="lerlum.jpg" width="430">
         <br>
         <br>    
         
    <label>Email Address</label>   
    <input type="text" name="email" autocomplete="off">
    
    <input style="float: left;
	background: #007BFF;
	padding: 10px 15px;
	color: #fff;
	border-radius: 5px;
	margin-left: 10px;
	border: none;" type="submit" name="submit" value="Reset Password">
          
</form>
    
</body>
</html>












