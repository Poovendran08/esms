<?php
include("user-account-dev.php");
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="32x32" href="static/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="static/favicons/favicon-16x16.png">
    <title>E-Staff Movement System</title>
    <link rel="stylesheet" href="static/css/custom-font.css">
    <link rel="stylesheet" href="static/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="static/css/fontawesome.min.css">
    <link rel="stylesheet" href="static/css/solid.min.css">
    <link rel="stylesheet" href="static/css/esms.min.css">
  </head>

  <body>
    <?php include 'navigation.php'; ?>
    <div class="container-fluid pb-1">
      <h1 class="h3 mb-4 font-weight-light">Users</h1>

      <div class="card mb-5 shadow">
        <div class="card-header">
          <h2 class="h6 mb-0 font-weight-bold">All users</h2>
        </div>

        <div class="card-body pt-3">
          <div class="mb-3">
            <a href="register.php" class="text-decoration-none">
              <i class="fa-solid fa-plus" aria-hidden="true"></i>
              Add new user
            </a>
          </div>

          <div class="table-responsive">
            <table class="table dataTables table-bordered nowrap">
              <thead>
                <tr>
                  <th>User ID</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>User type</th>
                  <th>Actions</th>
                </tr>
              </thead>
         
             <tbody>
                <?php
                  if(is_array($fetchData)){      
                  $sn=1;
                  foreach($fetchData as $data){
                ?>
                  <tr>
                  <td><?php echo $data['employee_id']??''; ?></td>
                  <td><?php echo $data['username']??''; ?></td>
                  <td><?php echo $data['email']??''; ?></td>
                  <td><?php echo $data['user_type']??''; ?></td>
                      
                  <td class="pt-1 pb-0">
                    <button type="button" onclick="location.href = 'update-user.php';" class="btn btn-outline-warning">Update</button>
                    <button type="button" class="btn btn-outline-danger" data-toggle="modal" data-target="#deleteUser">Delete</button>
                 </td>
                      
                 </tr>
                 <?php
                  $sn++;}}else{ ?>
                  <tr>
                    <td colspan="8">
                <?php echo $fetchData; ?>
                </td>
                <tr>
                <?php
                }?>     
            </tbody>
                
            </table>

            <div id="deleteUser" class="modal fade" tabindex="-1" role="dialog">
              <div class="modal-dialog" role="document">
                <div class="modal-content">
                  <div class="modal-header">
                    <p class="modal-title h5">Notice</p>

                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>

                  <p class="modal-body mb-0">Are you sure you want to delete the selected user's account?</p>

                  <div class="modal-footer">
                    <form action="#" method="post">
                      <button type="submit" class="btn btn-primary" name="deleteUser">Yes</button>
                    </form>

                    <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php include 'footer.php'; ?>

    <script src="static/js/jquery.min.js"></script>
    <script src="static/js/popper.min.js"></script>
    <script src="static/js/bootstrap.min.js"></script>
    <script src="static/js/jquery.dataTables.min.js"></script>
    <script src="static/js/datatables-initialization.js"></script>
    <script src="static/js/dataTables.bootstrap4.min.js"></script>
    <script src="static/js/solid.min.js"></script>
  </body>
</html>
<!-- User interface and php code done by poovendran -->
<!-- User interface edited by Thu Wen Bin -->
<!-- User interface and php code edited again by poovendran -->
