<?php include('../functions.php'); 

if(!isset($_GET["code"])){
    exit("Can't find the page");
}

$code = $_GET["code"];

$getEmailQuery = mysqli_query($conn, "SELECT email FROM resetPasswords WHERE code='$code'");
if(mysqli_num_rows($getEmailQuery) ==0){
    exit("Can't find the page");
}

if(isset($_POST["password"])){
    $pw = $_POST["password"];
    $pw = md5($pw); //encryption
    
    $row = mysqli_fetch_array($getEmailQuery);
    $email = $row["email"];
    
    $query = mysqli_query($conn, "UPDATE users SET password='$pw' WHERE email='$email'");
    
    if($query){
        $query = mysqli_query($conn, "DELETE FROM resetPasswords WHERE code='$code'");
        exit("Password updated");
    }
    else{
        exit("Something went wrong");
    }
}
?>







<!DOCTYPE html>
<html>
<head>
	
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
     <form method="post">
         
     <img src="lerlum.jpg" width="430">
         <br>
         <br>    
         
    <label>New password</label>   
         
         
    <input type="password" name="password">   
    
    <input style="float: left;
	background: #007BFF;
	padding: 10px 15px;
	color: #fff;
	border-radius: 5px;
	margin-left: 10px;
	border: none;" type="submit" name="submit" value="Update password">
                        
</form>
</body>
</html>




    