<?php 
    include('functions.php');
    
    if (!isLoggedIn()) {
	$_SESSION['msg'] = "You must log in first";
	header('location: login.php');
}
?>
<!-- php code by Povendran -->

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="32x32" href="static/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="static/favicons/favicon-16x16.png">
    <title>E-Staff Movement System</title>
    <link rel="stylesheet" href="static/css/custom-font.css">
    <link rel="stylesheet" href="static/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="static/css/fontawesome.min.css">
    <link rel="stylesheet" href="static/css/solid.min.css">
    <link rel="stylesheet" href="static/css/esms.min.css">
  </head>

  <body>
    <?php include 'navigation.php'; ?>
    <div class="container-fluid pb-1">
      <h1 class="h3 mb-4 font-weight-light">History</h1>

      <div class="card mb-4 shadow">
        <div class="card-header">
          <h2 class="h6 mb-0 font-weight-bold">Departure history</h2>
        </div>

        <div class="card-body pt-3">
          <div class="table-responsive">
            <table class="table dataTables table-bordered nowrap">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Departure date</th>
                  <th>Departure time</th>
                  <th>Location</th>
                  <th>Return date</th>
                  <th>Return time</th>
                  <th>Purpose</th>
                </tr>
              </thead>

              <tbody>
                <tr>
                  <td>Jane Doe</td>
                  <td>10/10/2022</td>
                  <td>02:00 PM</td>
                  <td>Ler Lum Advisory Services Sdn Bhd</td>
                  <td>10/10/2022</td>
                  <td>04:00 PM</td>
                  <td>Meeting with a client</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="card mb-5 shadow">
        <div class="card-header">
          <h2 class="h6 mb-0 font-weight-bold">Leave history</h2>
        </div>

        <div class="card-body pt-3">
          <div class="table-responsive">
            <table class="table dataTables table-bordered nowrap">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Type of leave</th>
                  <th>Duration of leave</th>
                  <th>Date of leave</th>
                  <th>Purpose of leave</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                <tr>
                  <td>John Doe</td>
                  <td>Medical leave</td>
                  <td>1 day</td>
                  <td>10/10/2022</td>
                  <td>Recovering from the flu</td>
                  <td class="text-success">Approved</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
    <?php include 'footer.php'; ?>

    <script src="static/js/jquery.min.js"></script>
    <script src="static/js/popper.min.js"></script>
    <script src="static/js/bootstrap.min.js"></script>
    <script src="static/js/jquery.dataTables.min.js"></script>
    <script src="static/js/datatables-initialization.js"></script>
    <script src="static/js/dataTables.bootstrap4.min.js"></script>
    <script src="static/js/solid.min.js"></script>
  </body>
</html>
<!-- User interface design by Thu Wen Bin -->
