<?php include('../functions.php'); ?>
<!-- php code by Povendran -->

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="icon" type="image/png" sizes="32x32" href="static/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="static/favicons/favicon-16x16.png">
    <title>E-Staff Movement System</title>
    <link rel="stylesheet" href="static/css/custom-font.css">
    <link rel="stylesheet" href="static/css/fontawesome.min.css">
    <link rel="stylesheet" href="static/css/solid.min.css">
    <link rel="stylesheet" href="static/css/esms.min.css">
  </head>

  <body>
    <?php include 'navigation.php'; ?>
    <div class="container-fluid pb-1">
      <h1 class="h3 mb-4 font-weight-light">Users > All users > Add new user</h1>

      <div class="card mb-5 shadow">
        <div class="card-header">
          <h2 class="h6 mb-0 font-weight-bold">User details</h2>
        </div>

        <div class="card-body pt-3">
          <div class="d-flex justify-content-center">
              
    <form method="post" action="register.php">
	<?php echo display_error(); ?>
    
    <div class="form-group">
		<label>Employee Name</label>
		<input type="text" id="name" class="form-control" placeholder="Enter employee name" name="name" value="<?php echo $name; ?>" required>
	</div>
	<div class="form-group">
		<label>Username</label>
		<input type="text" id="username" class="form-control" placeholder="Enter username" name="username" value="<?php echo $username; ?>" required>
	</div>
	<div class="form-group">
		<label>Email</label>
		<input type="email" id="email" class="form-control" placeholder="Enter email" name="email" value="<?php echo $email; ?>" required>
	</div>
    
    <div class="form-group">
			<label>User type</label>
        <select name="user_type" class="form-control" id="user_type" >
				<option value="">Select user type</option>
				<option value="admin">Admin</option>
				<option value="user">User</option>
			</select>
		</div>
    
	<div class="form-group">
		<label for="password_1">Password</label>
		<input type="password" id="password_1" class="form-control" placeholder="Enter password" name="password_1" required>
	</div>
	<div class="form-group">
		<label for="password_2">Confirm password</label>
		<input type="password" id="password_2" class="form-control" placeholder="Enter confirm password" name="password_2" required>
	</div>
	<div class="form-group">
		<button class="btn btn-primary" type="submit" class="btn" name="register_btn">Save</button>
	</div>
</form>
              
          </div>
        </div>
      </div>
    </div>
    <?php include 'footer.php'; ?>

    <script src="static/js/jquery.min.js"></script>
    <script src="static/js/popper.min.js"></script>
    <script src="static/js/bootstrap.min.js"></script>
    <script src="static/js/solid.min.js"></script>
  </body>
</html>
<!-- User interface design and php code by Poovendran -->
